import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:confetti/confetti.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:table_calendar/table_calendar.dart';

import 'package:google_sign_in/google_sign_in.dart';
import 'package:googleapis/drive/v3.dart' as drive;
import 'package:extension_google_sign_in_as_googleapis_auth/extension_google_sign_in_as_googleapis_auth.dart';

const String kBoxName = 'db';

// Data keys
const String kTasksKey = 'tasks_v2';
const String kLogsKey = 'logs_v2';

// Snapshots + UI state
const String kSeriSnapKey = 'seri_snaps_v1';
const String kUiStateKey = 'ui_state_v2';

// UI fields
const String kUiLastBreakShown = 'last_break_shown'; // YYYY-MM-DD
const String kUiDriveEnabled = 'drive_enabled'; // bool
const String kUiDriveLastBackup = 'drive_last_backup'; // YYYY-MM-DD
const String kUiTargetRatio = 'target_ratio'; // double
const String kUiLastConfetti =
    'last_confetti'; // YYYY-MM-DD (perfect-day confetti)
const String kUiThemeMode = 'theme_mode'; // "system" | "light" | "dark"

// Old keys (migration)
const String kOldTasksKey = 'tasks';
const String kOldLogsKey = 'logs';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  await Hive.openBox(kBoxName);
  runApp(const ChallengeTakipApp());
}

/// ------------------------------
/// Helpers
/// ------------------------------

DateTime dateOnly(DateTime d) => DateTime(d.year, d.month, d.day);

String dateKey(DateTime d) {
  final y = d.year.toString().padLeft(4, '0');
  final m = d.month.toString().padLeft(2, '0');
  final day = d.day.toString().padLeft(2, '0');
  return '$y-$m-$day';
}

String humanDate(DateTime d) {
  final dd = d.day.toString().padLeft(2, '0');
  final mm = d.month.toString().padLeft(2, '0');
  return '$dd.$mm.${d.year}';
}

String newId() {
  final r = Random.secure();
  final bytes = List<int>.generate(16, (_) => r.nextInt(256));
  return bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
}

bool taskIsValidOn(Map task, DateTime d) {
  final from = task['valid_from'] as String?;
  final to = task['valid_to'] as String?;
  if (from == null) return false;

  final dk = dateKey(d);
  final afterFrom = dk.compareTo(from) >= 0;
  final beforeTo = (to == null) || (dk.compareTo(to) <= 0);
  return afterFrom && beforeTo;
}

bool taskIsArchived(Map task) => (task['valid_to'] as String?) != null;

ThemeMode parseThemeMode(String? v) {
  switch (v) {
    case 'light':
      return ThemeMode.light;
    case 'dark':
      return ThemeMode.dark;
    case 'system':
    default:
      return ThemeMode.system;
  }
}

String themeModeToString(ThemeMode m) {
  switch (m) {
    case ThemeMode.light:
      return 'light';
    case ThemeMode.dark:
      return 'dark';
    case ThemeMode.system:
    default:
      return 'system';
  }
}

/// ------------------------------
/// Drive Service
/// ------------------------------

class DriveService {
  final GoogleSignIn _googleSignIn =
      GoogleSignIn(scopes: [drive.DriveApi.driveFileScope]);
  drive.DriveApi? _api;

  Future<bool> signInInteractive() async {
    final acc = await _googleSignIn.signIn();
    if (acc == null) return false;
    final client = await _googleSignIn.authenticatedClient();
    if (client == null) return false;
    _api = drive.DriveApi(client);
    return true;
  }

  Future<bool> signInSilent() async {
    try {
      final acc = await _googleSignIn.signInSilently();
      if (acc == null) return false;
      final client = await _googleSignIn.authenticatedClient();
      if (client == null) return false;
      _api = drive.DriveApi(client);
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<String?> _findBackupFileId() async {
    final res = await _api!.files.list(
      q: "name='challenge_backup.json' and trashed=false",
      spaces: "drive",
    );
    if (res.files == null || res.files!.isEmpty) return null;
    return res.files!.first.id;
  }

  Future<void> backupJson(Map<String, dynamic> data) async {
    final jsonStr = jsonEncode(data);
    final media =
        drive.Media(Stream.value(utf8.encode(jsonStr)), jsonStr.length);

    final existingId = await _findBackupFileId();
    if (existingId != null) {
      await _api!.files.update(drive.File(), existingId, uploadMedia: media);
    } else {
      await _api!.files.create(
        drive.File()
          ..name = 'challenge_backup.json'
          ..mimeType = 'application/json',
        uploadMedia: media,
      );
    }
  }

  Future<Map<String, dynamic>?> restoreJson() async {
    final id = await _findBackupFileId();
    if (id == null) return null;

    final media = await _api!.files.get(
      id,
      downloadOptions: drive.DownloadOptions.fullMedia,
    ) as drive.Media;

    final bytes = await media.stream.expand((e) => e).toList();
    final jsonStr = utf8.decode(bytes);
    final decoded = jsonDecode(jsonStr);

    if (decoded is Map<String, dynamic>) return decoded;
    if (decoded is Map) return Map<String, dynamic>.from(decoded);
    return null;
  }
}

/// ------------------------------
/// Repo
/// ------------------------------

class Repo {
  final Box box = Hive.box(kBoxName);

  void ensureInitializedAndMigrateIfNeeded() {
    if (box.get(kTasksKey) == null) box.put(kTasksKey, <dynamic>[]);
    if (box.get(kLogsKey) == null) box.put(kLogsKey, <String, dynamic>{});
    if (box.get(kSeriSnapKey) == null)
      box.put(kSeriSnapKey, <String, dynamic>{});
    if (box.get(kUiStateKey) == null) {
      box.put(kUiStateKey, <String, dynamic>{
        kUiDriveEnabled: false,
        kUiTargetRatio: 0.80,
        kUiThemeMode: 'system',
      });
    }

    // migrate from old template if v2 empty and old exists
    final v2Tasks = box.get(kTasksKey);
    final hasV2Tasks = (v2Tasks is List) && v2Tasks.isNotEmpty;

    final oldTasks = box.get(kOldTasksKey);
    final oldLogs = box.get(kOldLogsKey);

    if (!hasV2Tasks && oldTasks is List && oldTasks.isNotEmpty) {
      final today = dateKey(dateOnly(DateTime.now()));
      final List<Map<String, dynamic>> migratedTasks = [];
      int sort = 1;

      for (final t in oldTasks) {
        if (t is String && t.trim().isNotEmpty) {
          migratedTasks.add({
            'id': newId(),
            'name': t.trim(),
            'sort': sort++,
            'valid_from': today,
            'valid_to': null,
          });
        }
      }

      final Map<String, String> nameToId = {
        for (final t in migratedTasks)
          (t['name'] as String): (t['id'] as String),
      };

      final Map<String, dynamic> migratedLogs = {};
      if (oldLogs is Map) {
        oldLogs.forEach((d, raw) {
          if (d is! String) return;
          final Map<String, bool> day = {};
          if (raw is Map) {
            raw.forEach((k, v) {
              if (k is String) {
                final id = nameToId[k];
                if (id != null) day[id] = (v == true);
              }
            });
          }
          migratedLogs[d] = day;
        });
      }

      box.put(kTasksKey, migratedTasks);
      box.put(kLogsKey, migratedLogs);
    }

    // Defaults if empty
    final tasksNow = box.get(kTasksKey);
    if (tasksNow is List && tasksNow.isEmpty) {
      final today = dateKey(dateOnly(DateTime.now()));
      const defaults = <String>[
        '7’de kalk',
        'Spor',
        'Kitap oku',
        '104 şınav',
        'Sigara içme',
        'Çalışma',
        'Şükret',
        'Gitar',
        'Yatış',
      ];

      int sort = 1;
      final list = defaults.map((name) {
        return {
          'id': newId(),
          'name': name,
          'sort': sort++,
          'valid_from': today,
          'valid_to': null
        };
      }).toList();

      box.put(kTasksKey, list);
    }
  }

  List<Map<String, dynamic>> getAllTasks() {
    final raw = box.get(kTasksKey);
    if (raw is List) {
      final list = raw
          .whereType<Map>()
          .map((m) => Map<String, dynamic>.from(m))
          .toList();
      list.sort(
          (a, b) => (a['sort'] as int? ?? 0).compareTo(b['sort'] as int? ?? 0));
      return list;
    }
    return <Map<String, dynamic>>[];
  }

  Map<String, dynamic> getAllLogs() {
    final raw = box.get(kLogsKey);
    if (raw is Map) return Map<String, dynamic>.from(raw);
    return <String, dynamic>{};
  }

  Map<String, dynamic> getSeriSnaps() {
    final raw = box.get(kSeriSnapKey);
    if (raw is Map) return Map<String, dynamic>.from(raw);
    return <String, dynamic>{};
  }

  Map<String, dynamic> getUiState() {
    final raw = box.get(kUiStateKey);
    if (raw is Map) return Map<String, dynamic>.from(raw);
    return <String, dynamic>{};
  }

  Future<void> setUiValue(String key, dynamic value) async {
    final ui = getUiState();
    ui[key] = value;
    await box.put(kUiStateKey, ui);
  }

  bool driveEnabled() => getUiState()[kUiDriveEnabled] == true;

  String? driveLastBackupKey() {
    final v = getUiState()[kUiDriveLastBackup];
    return v is String ? v : null;
  }

  double targetRatio() {
    final t = getUiState()[kUiTargetRatio];
    return t is num ? t.toDouble() : 0.80;
  }

  ThemeMode themeMode() =>
      parseThemeMode(getUiState()[kUiThemeMode] as String?);

  String? lastConfettiKey() {
    final v = getUiState()[kUiLastConfetti];
    return v is String ? v : null;
  }

  Map<String, bool> logsForDate(DateTime d) {
    final all = getAllLogs();
    final k = dateKey(d);
    final raw = all[k];
    if (raw is Map) {
      final result = <String, bool>{};
      raw.forEach((kk, vv) {
        if (kk is String) result[kk] = vv == true;
      });
      return result;
    }
    return <String, bool>{};
  }

  bool isTaskDone(DateTime d, String taskId) => logsForDate(d)[taskId] == true;

  int totalCountForDate(DateTime d) =>
      getAllTasks().where((t) => taskIsValidOn(t, d)).length;

  int completedCountForDate(DateTime d) {
    final tasks = getAllTasks().where((t) => taskIsValidOn(t, d)).toList();
    if (tasks.isEmpty) return 0;
    final logs = logsForDate(d);
    int done = 0;
    for (final t in tasks) {
      final id = t['id'] as String;
      if (logs[id] == true) done++;
    }
    return done;
  }

  double ratioForDate(DateTime d) {
    final total = totalCountForDate(d);
    if (total == 0) return 0;
    return completedCountForDate(d) / total;
  }

  bool isPerfectDay(DateTime d) =>
      totalCountForDate(d) > 0 && ratioForDate(d) >= 1.0;

  int currentSeri() {
    final today = dateOnly(DateTime.now());
    int seri = 0;
    DateTime cursor = today;
    while (true) {
      if (!isPerfectDay(cursor)) break;
      seri++;
      cursor = cursor.subtract(const Duration(days: 1));
    }
    return seri;
  }

  int longestSeri() {
    final logKeys = getAllLogs().keys.whereType<String>().toList();
    final snapKeys = getSeriSnaps().keys.whereType<String>().toList();
    final allKeys = {...logKeys, ...snapKeys}.toList()..sort();
    if (allKeys.isEmpty) return 0;

    int maxSeri = 0, cur = 0;
    DateTime? prev;

    for (final k in allKeys) {
      DateTime d;
      try {
        d = DateTime.parse(k);
      } catch (_) {
        continue;
      }

      final perfect = isPerfectDay(d);
      if (perfect) {
        if (prev != null && d.difference(prev).inDays == 1) {
          cur++;
        } else {
          cur = 1;
        }
        maxSeri = max(maxSeri, cur);
      } else {
        cur = 0;
      }
      prev = d;
    }
    return maxSeri;
  }

  Future<void> writeSeriSnapshotIfPerfect(DateTime d) async {
    final day = dateOnly(d);
    if (!isPerfectDay(day)) return;

    final snaps = getSeriSnaps();
    final key = dateKey(day);
    snaps[key] = {
      'perfect': true,
      'total': totalCountForDate(day),
      'done': completedCountForDate(day),
      'at': DateTime.now().toIso8601String(),
    };
    await box.put(kSeriSnapKey, snaps);
  }

  Future<void> setDone(DateTime d, String taskId, bool done) async {
    final all = getAllLogs();
    final key = dateKey(d);
    final current = logsForDate(d);
    current[taskId] = done;
    all[key] = current;
    await box.put(kLogsKey, all);
    await writeSeriSnapshotIfPerfect(d);
  }

  Future<void> resetDay(DateTime d) async {
    final all = getAllLogs();
    all.remove(dateKey(d));
    await box.put(kLogsKey, all);
  }

  Future<void> addTask(String name) async {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return;

    final tasks = getAllTasks();
    final today = dateOnly(DateTime.now());

    final existsActive = tasks.any((t) =>
        (t['name'] as String?)?.toLowerCase() == trimmed.toLowerCase() &&
        taskIsValidOn(t, today));
    if (existsActive) return;

    final todayKey = dateKey(today);
    final nextSort = tasks.isEmpty
        ? 1
        : (tasks.map((t) => t['sort'] as int? ?? 0).fold<int>(0, max) + 1);

    tasks.add({
      'id': newId(),
      'name': trimmed,
      'sort': nextSort,
      'valid_from': todayKey,
      'valid_to': null
    });
    await box.put(kTasksKey, tasks);
  }

  Future<void> renameTask(String taskId, String newName) async {
    final trimmed = newName.trim();
    if (trimmed.isEmpty) return;

    final tasks = getAllTasks();
    final idx = tasks.indexWhere((t) => t['id'] == taskId);
    if (idx == -1) return;

    final today = dateOnly(DateTime.now());
    final conflict = tasks.any((t) =>
        t['id'] != taskId &&
        (t['name'] as String?)?.toLowerCase() == trimmed.toLowerCase() &&
        taskIsValidOn(t, today));
    if (conflict) return;

    tasks[idx]['name'] = trimmed;
    await box.put(kTasksKey, tasks);
  }

  Future<void> archiveTask(String taskId) async {
    final tasks = getAllTasks();
    final todayKey = dateKey(dateOnly(DateTime.now()));
    final idx = tasks.indexWhere((t) => t['id'] == taskId);
    if (idx == -1) return;
    if (tasks[idx]['valid_to'] != null) return;
    tasks[idx]['valid_to'] = todayKey;
    await box.put(kTasksKey, tasks);
  }

  Future<void> restoreTask(String taskId) async {
    final tasks = getAllTasks();
    final idx = tasks.indexWhere((t) => t['id'] == taskId);
    if (idx == -1) return;
    tasks[idx]['valid_to'] = null;
    await box.put(kTasksKey, tasks);
  }

  Future<void> deleteTaskPermanently(String taskId) async {
    final tasks = getAllTasks();
    tasks.removeWhere((t) => t['id'] == taskId);
    await box.put(kTasksKey, tasks);

    final logs = getAllLogs();
    bool changed = false;
    logs.forEach((_, raw) {
      if (raw is Map && raw.containsKey(taskId)) {
        raw.remove(taskId);
        changed = true;
      }
    });
    if (changed) await box.put(kLogsKey, logs);
  }

  Map<String, dynamic> exportAllData() {
    return {
      'tasks': box.get(kTasksKey),
      'logs': box.get(kLogsKey),
      'seri': box.get(kSeriSnapKey),
      'ui': box.get(kUiStateKey)
    };
  }

  Future<void> importAllData(Map<String, dynamic> data) async {
    if (data.containsKey('tasks')) await box.put(kTasksKey, data['tasks']);
    if (data.containsKey('logs')) await box.put(kLogsKey, data['logs']);
    if (data.containsKey('seri')) await box.put(kSeriSnapKey, data['seri']);
    if (data.containsKey('ui')) await box.put(kUiStateKey, data['ui']);
  }
}

/// ------------------------------
/// App
/// ------------------------------

class ChallengeTakipApp extends StatefulWidget {
  const ChallengeTakipApp({super.key});

  @override
  State<ChallengeTakipApp> createState() => _ChallengeTakipAppState();
}

class _ChallengeTakipAppState extends State<ChallengeTakipApp> {
  final Repo repo = Repo();

  @override
  void initState() {
    super.initState();
    repo.ensureInitializedAndMigrateIfNeeded();
  }

  @override
  Widget build(BuildContext context) {
    final mode = repo.themeMode();
    final seed = const Color(0xFF2E7D32);

    final light = ThemeData(
      useMaterial3: true,
      colorSchemeSeed: seed,
      brightness: Brightness.light,
      visualDensity: VisualDensity.adaptivePlatformDensity,
    );

    final dark = ThemeData(
      useMaterial3: true,
      colorSchemeSeed: seed,
      brightness: Brightness.dark,
      visualDensity: VisualDensity.adaptivePlatformDensity,
    );

    return MaterialApp(
      title: 'Challenge Takip',
      debugShowCheckedModeBanner: false,
      theme: light,
      darkTheme: dark,
      themeMode: mode,
      home: HomeShell(repo: repo),
    );
  }
}

/// ------------------------------
/// Home shell (lifecycle -> auto backup)
/// ------------------------------

class HomeShell extends StatefulWidget {
  final Repo repo;
  const HomeShell({super.key, required this.repo});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> with WidgetsBindingObserver {
  Repo get repo => widget.repo;
  final DriveService driveService = DriveService();

  int _index = 0;
  DateTime _selectedDate = DateTime.now();
  bool _autoBusy = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    unawaited(_autoBackupIfNeeded());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed ||
        state == AppLifecycleState.paused) {
      unawaited(_autoBackupIfNeeded());
    }
  }

  Future<void> _autoBackupIfNeeded() async {
    if (_autoBusy) return;
    if (!repo.driveEnabled()) return;

    final todayKey = dateKey(dateOnly(DateTime.now()));
    if (repo.driveLastBackupKey() == todayKey) return;

    _autoBusy = true;
    try {
      final ok = await driveService.signInSilent();
      if (!ok) return;
      await driveService.backupJson(repo.exportAllData());
      await repo.setUiValue(kUiDriveLastBackup, todayKey);
    } finally {
      _autoBusy = false;
    }
  }

  void _goToDate(DateTime d) {
    setState(() {
      _selectedDate = dateOnly(d);
      _index = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      TodayScreen(
        repo: repo,
        driveService: driveService,
        initialDate: _selectedDate,
        onDatePicked: (d) => setState(() => _selectedDate = d),
        onOpenSettings: () async {
          await Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => SettingsScreen(repo: repo)));
          setState(() {}); // theme/flags refresh
        },
      ),
      CalendarScreen(
          repo: repo,
          initialSelectedDate: _selectedDate,
          onDateSelected: _goToDate),
      TasksScreen(repo: repo),
      AnalyticsScreen(repo: repo),
    ];

    return Scaffold(
      body: AnimatedSwitcher(
        duration: const Duration(milliseconds: 220),
        switchInCurve: Curves.easeOut,
        switchOutCurve: Curves.easeIn,
        child: pages[_index],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.checklist), label: 'Bugün'),
          NavigationDestination(
              icon: Icon(Icons.calendar_month), label: 'Takvim'),
          NavigationDestination(icon: Icon(Icons.tune), label: 'Görevler'),
          NavigationDestination(icon: Icon(Icons.insights), label: 'Analitik'),
        ],
      ),
    );
  }
}

/// ------------------------------
/// Settings (product polish)
/// ------------------------------

class SettingsScreen extends StatefulWidget {
  final Repo repo;
  const SettingsScreen({super.key, required this.repo});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  Repo get repo => widget.repo;

  @override
  Widget build(BuildContext context) {
    final enabled = repo.driveEnabled();
    final target = repo.targetRatio();
    final mode = repo.themeMode();

    return Scaffold(
      appBar: AppBar(title: const Text('Ayarlar')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _SectionCard(
            title: 'Görünüm',
            child: Column(
              children: [
                RadioListTile<ThemeMode>(
                  title: const Text('Sistem'),
                  value: ThemeMode.system,
                  groupValue: mode,
                  onChanged: (_) async {
                    await repo.setUiValue(kUiThemeMode, 'system');
                    if (mounted) setState(() {});
                  },
                ),
                RadioListTile<ThemeMode>(
                  title: const Text('Açık'),
                  value: ThemeMode.light,
                  groupValue: mode,
                  onChanged: (_) async {
                    await repo.setUiValue(kUiThemeMode, 'light');
                    if (mounted) setState(() {});
                  },
                ),
                RadioListTile<ThemeMode>(
                  title: const Text('Koyu'),
                  value: ThemeMode.dark,
                  groupValue: mode,
                  onChanged: (_) async {
                    await repo.setUiValue(kUiThemeMode, 'dark');
                    if (mounted) setState(() {});
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _SectionCard(
            title: 'Hedef',
            child: Row(
              children: [
                Expanded(
                    child: Text('Hedef başarı: ${(target * 100).round()}%')),
                IconButton(
                  onPressed: () async {
                    final c = TextEditingController(
                        text: ((target * 100).round()).toString());
                    final ok = await showDialog<bool>(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        title: const Text('Hedef (%)'),
                        content: TextField(
                            controller: c, keyboardType: TextInputType.number),
                        actions: [
                          TextButton(
                              onPressed: () => Navigator.of(ctx).pop(false),
                              child: const Text('İptal')),
                          ElevatedButton(
                              onPressed: () => Navigator.of(ctx).pop(true),
                              child: const Text('Kaydet')),
                        ],
                      ),
                    );
                    if (ok == true) {
                      final v = int.tryParse(c.text.trim());
                      if (v != null) {
                        await repo.setUiValue(
                            kUiTargetRatio, v.clamp(0, 100) / 100.0);
                        if (mounted) setState(() {});
                      }
                    }
                  },
                  icon: const Icon(Icons.edit),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _SectionCard(
            title: 'Drive Yedek',
            child: SwitchListTile(
              title: const Text('Otomatik günlük yedek'),
              subtitle: Text(enabled ? 'Açık' : 'Kapalı'),
              value: enabled,
              onChanged: (v) async {
                await repo.setUiValue(kUiDriveEnabled, v);
                if (mounted) setState(() {});
              },
            ),
          ),
          const SizedBox(height: 12),
          _SectionCard(
            title: 'Gelişmiş',
            child: ListTile(
              leading: const Icon(Icons.restore),
              title: const Text('Bugün confetti tekrar gösterilsin'),
              subtitle: const Text('Yalnızca görsel; veriyi etkilemez'),
              onTap: () async {
                await repo.setUiValue(kUiLastConfetti, null);
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Sıfırlandı')));
                }
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  final String title;
  final Widget child;
  const _SectionCard({required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0.6,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title,
              style: Theme.of(context)
                  .textTheme
                  .titleMedium
                  ?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          child,
        ]),
      ),
    );
  }
}

/// ------------------------------
/// Today (product polish + ring + confetti)
/// ------------------------------

class TodayScreen extends StatefulWidget {
  final Repo repo;
  final DriveService driveService;

  final DateTime initialDate;
  final ValueChanged<DateTime> onDatePicked;
  final VoidCallback onOpenSettings;

  const TodayScreen({
    super.key,
    required this.repo,
    required this.driveService,
    required this.initialDate,
    required this.onDatePicked,
    required this.onOpenSettings,
  });

  @override
  State<TodayScreen> createState() => _TodayScreenState();
}

class _TodayScreenState extends State<TodayScreen> {
  late DateTime _selectedDate;
  late ConfettiController _confetti;

  Repo get repo => widget.repo;
  DriveService get driveService => widget.driveService;

  @override
  void initState() {
    super.initState();
    _selectedDate = dateOnly(widget.initialDate);
    _confetti = ConfettiController(duration: const Duration(milliseconds: 900));
  }

  @override
  void dispose() {
    _confetti.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final first = DateTime(now.year - 2, 1, 1);
    final last = DateTime(now.year + 2, 12, 31);

    final picked = await showDatePicker(
        context: context,
        initialDate: _selectedDate,
        firstDate: first,
        lastDate: last);
    if (picked != null) {
      final d = dateOnly(picked);
      setState(() => _selectedDate = d);
      widget.onDatePicked(d);
    }
  }

  Future<void> _showAddTaskDialog() async {
    final controller = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Görev ekle'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Örn: 30 dk yürüyüş'),
          onSubmitted: (_) => Navigator.of(ctx).pop(true),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(ctx).pop(false),
              child: const Text('İptal')),
          ElevatedButton(
              onPressed: () => Navigator.of(ctx).pop(true),
              child: const Text('Ekle')),
        ],
      ),
    );
    if (ok == true) {
      await repo.addTask(controller.text);
      if (mounted) setState(() {});
    }
  }

  Future<void> _manualBackup() async {
    try {
      final ok = await driveService.signInInteractive();
      if (!ok) return;
      await repo.setUiValue(kUiDriveEnabled, true);
      await driveService.backupJson(repo.exportAllData());
      await repo.setUiValue(
          kUiDriveLastBackup, dateKey(dateOnly(DateTime.now())));
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Drive yedek tamamlandı')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Yedek hata: $e')));
    }
  }

  Future<void> _manualRestore() async {
    try {
      final ok = await driveService.signInInteractive();
      if (!ok) return;
      final data = await driveService.restoreJson();
      if (data == null) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Drive yedeği bulunamadı')));
        return;
      }
      await repo.importAllData(data);
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Drive geri yüklendi')));
      setState(() {});
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Geri yükleme hata: $e')));
    }
  }

  Future<void> _maybeShowSeriBrokenDialogIfNeeded() async {
    final today = dateOnly(DateTime.now());
    if (!repo.isPerfectDay(today)) return;

    final yesterday = today.subtract(const Duration(days: 1));
    if (repo.isPerfectDay(yesterday)) return;

    final ui = repo.getUiState();
    final lastShown = ui[kUiLastBreakShown] as String?;
    final todayKey = dateKey(today);
    if (lastShown == todayKey) return;

    await repo.setUiValue(kUiLastBreakShown, todayKey);
    if (!mounted) return;

    await showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'Seri',
      pageBuilder: (_, __, ___) => const SizedBox.shrink(),
      transitionDuration: const Duration(milliseconds: 260),
      transitionBuilder: (context, anim, __, ___) {
        final curve = CurvedAnimation(parent: anim, curve: Curves.easeOutBack);
        return Opacity(
          opacity: anim.value,
          child: Transform.scale(
            scale: 0.92 + (0.08 * curve.value),
            child: AlertDialog(
              title: Row(
                children: const [
                  Icon(Icons.broken_image, color: Colors.deepOrange),
                  SizedBox(width: 8),
                  Text('Seri kırıldı'),
                ],
              ),
              content: Text(
                  'Dün %100 olmadı. Bugün yeni bir Seri başlattın.\n\nEn uzun Seri: ${repo.longestSeri()}'),
              actions: [
                ElevatedButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: const Text('Devam')),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _maybeConfettiIfPerfectToday() async {
    final d = dateOnly(_selectedDate);
    final dk = dateKey(d);
    if (!repo.isPerfectDay(d)) return;
    if (repo.lastConfettiKey() == dk) return;

    await repo.setUiValue(kUiLastConfetti, dk);
    _confetti.play();
  }

  @override
  Widget build(BuildContext context) {
    final allTasks = repo.getAllTasks();
    final validTasks =
        allTasks.where((t) => taskIsValidOn(t, _selectedDate)).toList();
    final logs = repo.logsForDate(_selectedDate);

    final total = validTasks.length;
    final done = repo.completedCountForDate(_selectedDate);
    final ratio = repo.ratioForDate(_selectedDate);

    final seriNow = repo.currentSeri();
    final seriMax = repo.longestSeri();

    final cs = Theme.of(context).colorScheme;
    final ringColor = ratio >= 1.0 ? cs.primary : cs.tertiary;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Challenge Takip'),
        actions: [
          IconButton(
              tooltip: 'Ayarlar',
              onPressed: widget.onOpenSettings,
              icon: const Icon(Icons.settings)),
          IconButton(
              tooltip: 'Tarih seç',
              onPressed: _pickDate,
              icon: const Icon(Icons.calendar_month)),
          IconButton(
              tooltip: 'Görev ekle',
              onPressed: _showAddTaskDialog,
              icon: const Icon(Icons.add)),
          IconButton(
              tooltip: 'Drive yedek',
              onPressed: _manualBackup,
              icon: const Icon(Icons.cloud_upload)),
          IconButton(
              tooltip: 'Drive geri yükle',
              onPressed: _manualRestore,
              icon: const Icon(Icons.cloud_download)),
        ],
      ),
      body: Stack(
        children: [
          Align(
            alignment: Alignment.topCenter,
            child: ConfettiWidget(
              confettiController: _confetti,
              blastDirectionality: BlastDirectionality.explosive,
              numberOfParticles: 18,
              gravity: 0.25,
              emissionFrequency: 0.02,
              shouldLoop: false,
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                // Header + Ring
                Card(
                  elevation: 0.6,
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(humanDate(_selectedDate),
                                    style: const TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.w900)),
                                const SizedBox(height: 6),
                                Text('Tamamlanan: $done / $total',
                                    style:
                                        TextStyle(color: cs.onSurfaceVariant)),
                                const SizedBox(height: 8),
                                Wrap(spacing: 10, runSpacing: 8, children: [
                                  _Pill(
                                      icon: Icons.local_fire_department,
                                      label: 'Seri: $seriNow',
                                      tone: cs.primary),
                                  _Pill(
                                      icon: Icons.emoji_events,
                                      label: 'En Uzun: $seriMax',
                                      tone: cs.tertiary),
                                ]),
                              ]),
                        ),
                        const SizedBox(width: 10),
                        _ProgressRing(
                          percent: ratio,
                          color: ringColor,
                          size: 92,
                          label: '${(ratio * 100).round()}%',
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 12),

                // Quick actions
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: total == 0
                            ? null
                            : () async {
                                await repo.resetDay(_selectedDate);
                                if (mounted) setState(() {});
                              },
                        icon: const Icon(Icons.restart_alt),
                        label: const Text('Günü Sıfırla'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () async {
                          await _maybeShowSeriBrokenDialogIfNeeded();
                          await _maybeConfettiIfPerfectToday();
                        },
                        icon: const Icon(Icons.auto_awesome),
                        label: const Text('Kontrol'),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 12),

                Expanded(
                  child: validTasks.isEmpty
                      ? const Center(
                          child: Text(
                              'Bu tarihte geçerli görev yok. + ile ekleyebilirsin.'))
                      : ListView.separated(
                          itemCount: validTasks.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(height: 8),
                          itemBuilder: (context, i) {
                            final task = validTasks[i];
                            final id = task['id'] as String;
                            final name = task['name'] as String;
                            final isDone = logs[id] == true;

                            return Card(
                              elevation: 0.4,
                              child: ListTile(
                                leading: AnimatedSwitcher(
                                  duration: const Duration(milliseconds: 180),
                                  child: isDone
                                      ? Icon(Icons.check_circle,
                                          key: ValueKey('d$id'),
                                          color: cs.primary)
                                      : Icon(Icons.radio_button_unchecked,
                                          key: ValueKey('u$id'),
                                          color: cs.outline),
                                ),
                                title: Text(
                                  name,
                                  style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    decoration: isDone
                                        ? TextDecoration.lineThrough
                                        : null,
                                  ),
                                ),
                                subtitle: isDone
                                    ? Text('Tamamlandı',
                                        style: TextStyle(color: cs.primary))
                                    : const Text(''),
                                trailing: Checkbox(
                                  value: isDone,
                                  onChanged: (v) async {
                                    await repo.setDone(
                                        _selectedDate, id, v ?? false);
                                    if (mounted) setState(() {});
                                    await _maybeConfettiIfPerfectToday();
                                  },
                                ),
                                onLongPress: () async {
                                  final ok = await showDialog<bool>(
                                    context: context,
                                    builder: (ctx) => AlertDialog(
                                      title:
                                          const Text('Görev arşivlensin mi?'),
                                      content: Text(
                                          '"$name" görevi bugünden itibaren arşivlenecek.\nGeçmiş günler korunur.'),
                                      actions: [
                                        TextButton(
                                            onPressed: () =>
                                                Navigator.of(ctx).pop(false),
                                            child: const Text('Vazgeç')),
                                        ElevatedButton(
                                            onPressed: () =>
                                                Navigator.of(ctx).pop(true),
                                            child: const Text('Arşivle')),
                                      ],
                                    ),
                                  );
                                  if (ok == true) {
                                    await repo.archiveTask(id);
                                    if (mounted) setState(() {});
                                  }
                                },
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color tone;
  const _Pill({required this.icon, required this.label, required this.tone});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: tone.withOpacity(
            Theme.of(context).brightness == Brightness.dark ? 0.22 : 0.14),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: cs.outlineVariant.withOpacity(0.6)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 16, color: tone),
        const SizedBox(width: 6),
        Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
      ]),
    );
  }
}

class _ProgressRing extends StatelessWidget {
  final double percent;
  final double size;
  final Color color;
  final String label;

  const _ProgressRing(
      {required this.percent,
      required this.size,
      required this.color,
      required this.label});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final p = percent.clamp(0.0, 1.0);

    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CircularProgressIndicator(
            value: 1,
            strokeWidth: 10,
            valueColor: AlwaysStoppedAnimation<Color>(
                cs.outlineVariant.withOpacity(0.35)),
          ),
          TweenAnimationBuilder<double>(
            tween: Tween(begin: 0, end: p),
            duration: const Duration(milliseconds: 420),
            curve: Curves.easeOutCubic,
            builder: (_, v, __) {
              return CircularProgressIndicator(
                value: v,
                strokeWidth: 10,
                strokeCap: StrokeCap.round,
                valueColor: AlwaysStoppedAnimation<Color>(color),
              );
            },
          ),
          Text(label,
              style:
                  const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
        ],
      ),
    );
  }
}

/// ------------------------------
/// Calendar (5 tier + flame)
/// ------------------------------

class CalendarScreen extends StatefulWidget {
  final Repo repo;
  final DateTime initialSelectedDate;
  final ValueChanged<DateTime> onDateSelected;

  const CalendarScreen({
    super.key,
    required this.repo,
    required this.initialSelectedDate,
    required this.onDateSelected,
  });

  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  Repo get repo => widget.repo;

  late DateTime _focusedDay;
  late DateTime _selectedDay;
  CalendarFormat _format = CalendarFormat.month;

  @override
  void initState() {
    super.initState();
    _selectedDay = dateOnly(widget.initialSelectedDate);
    _focusedDay = _selectedDay;
  }

  Color _tierColor(double ratio, ColorScheme cs) {
    if (ratio >= 0.80) return cs.primary;
    if (ratio >= 0.60) return cs.tertiary;
    if (ratio >= 0.40) return cs.secondary;
    if (ratio >= 0.20) return Colors.orange.shade700;
    return Colors.red.shade700;
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(title: const Text('Takvim')),
      body: Column(
        children: [
          TableCalendar(
            firstDay: DateTime.utc(2020, 1, 1),
            lastDay: DateTime.utc(2030, 12, 31),
            focusedDay: _focusedDay,
            calendarFormat: _format,
            startingDayOfWeek: StartingDayOfWeek.monday,
            selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
            onFormatChanged: (format) => setState(() => _format = format),
            onDaySelected: (selectedDay, focusedDay) {
              setState(() {
                _selectedDay = dateOnly(selectedDay);
                _focusedDay = dateOnly(focusedDay);
              });
              widget.onDateSelected(_selectedDay);
            },
            onPageChanged: (focusedDay) =>
                setState(() => _focusedDay = dateOnly(focusedDay)),
            calendarBuilders: CalendarBuilders(
              defaultBuilder: (context, day, _) {
                final r = repo.ratioForDate(dateOnly(day));
                return _dayCell(day, _tierColor(r, cs), cs, false,
                    selected: false);
              },
              todayBuilder: (context, day, _) {
                final r = repo.ratioForDate(dateOnly(day));
                return _dayCell(day, _tierColor(r, cs), cs, true,
                    selected: false);
              },
              selectedBuilder: (context, day, _) {
                final r = repo.ratioForDate(dateOnly(day));
                return _dayCell(day, _tierColor(r, cs), cs, true,
                    selected: true);
              },
            ),
          ),
          const SizedBox(height: 8),
          const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16), child: _Legend()),
          const SizedBox(height: 10),
        ],
      ),
    );
  }

  Widget _dayCell(DateTime day, Color color, ColorScheme cs, bool outlined,
      {required bool selected}) {
    final d = dateOnly(day);
    final perfect = repo.isPerfectDay(d);

    return Container(
      margin: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.95),
        borderRadius: BorderRadius.circular(12),
        border: outlined
            ? Border.all(
                color: selected ? cs.onSurface : cs.outlineVariant,
                width: selected ? 2 : 1)
            : null,
      ),
      alignment: Alignment.center,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Text('${day.day}',
              style: const TextStyle(
                  color: Colors.white, fontWeight: FontWeight.w900)),
          if (perfect)
            const Positioned(
              bottom: 2,
              right: 2,
              child: Icon(Icons.local_fire_department,
                  size: 12, color: Colors.white),
            ),
        ],
      ),
    );
  }
}

class _Legend extends StatelessWidget {
  const _Legend();

  @override
  Widget build(BuildContext context) {
    Widget dot(Color c) => Container(
        width: 12,
        height: 12,
        decoration: BoxDecoration(color: c, shape: BoxShape.circle));
    return Wrap(
      spacing: 10,
      runSpacing: 8,
      children: [
        Row(mainAxisSize: MainAxisSize.min, children: [
          dot(Colors.red.shade700),
          const SizedBox(width: 6),
          const Text('0–19%')
        ]),
        Row(mainAxisSize: MainAxisSize.min, children: [
          dot(Colors.orange.shade700),
          const SizedBox(width: 6),
          const Text('20–39%')
        ]),
        Row(mainAxisSize: MainAxisSize.min, children: [
          dot(Colors.green.shade400),
          const SizedBox(width: 6),
          const Text('40–59%')
        ]),
        Row(mainAxisSize: MainAxisSize.min, children: [
          dot(Colors.green.shade700),
          const SizedBox(width: 6),
          const Text('60–79%')
        ]),
        Row(mainAxisSize: MainAxisSize.min, children: [
          dot(Colors.green.shade900),
          const SizedBox(width: 6),
          const Text('80–100%')
        ]),
      ],
    );
  }
}

/// ------------------------------
/// Tasks management
/// ------------------------------

class TasksScreen extends StatefulWidget {
  final Repo repo;
  const TasksScreen({super.key, required this.repo});

  @override
  State<TasksScreen> createState() => _TasksScreenState();
}

class _TasksScreenState extends State<TasksScreen>
    with SingleTickerProviderStateMixin {
  Repo get repo => widget.repo;
  late TabController _tab;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  Future<void> _editTask(String id, String current) async {
    final c = TextEditingController(text: current);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Görev düzenle'),
        content: TextField(controller: c, autofocus: true),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(ctx).pop(false),
              child: const Text('İptal')),
          ElevatedButton(
              onPressed: () => Navigator.of(ctx).pop(true),
              child: const Text('Kaydet')),
        ],
      ),
    );
    if (ok == true) {
      await repo.renameTask(id, c.text);
      if (mounted) setState(() {});
    }
  }

  Future<void> _confirm(
      String title, String msg, Future<void> Function() action) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Text(msg),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(ctx).pop(false),
              child: const Text('Vazgeç')),
          ElevatedButton(
              onPressed: () => Navigator.of(ctx).pop(true),
              child: const Text('Onayla')),
        ],
      ),
    );
    if (ok == true) {
      await action();
      if (mounted) setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final tasks = repo.getAllTasks();
    final active = tasks.where((t) => !taskIsArchived(t)).toList();
    final archived = tasks.where((t) => taskIsArchived(t)).toList();

    Widget row(Map<String, dynamic> t, bool isArchived) {
      final id = t['id'] as String;
      final name = t['name'] as String;
      final from = t['valid_from'] as String? ?? '-';
      final to = t['valid_to'] as String?;

      return Card(
        elevation: 0.4,
        child: ListTile(
          title:
              Text(name, style: const TextStyle(fontWeight: FontWeight.w800)),
          subtitle: Text(isArchived
              ? 'Arşiv: $from → ${to ?? "-"}'
              : 'Aktif: $from → (devam)'),
          trailing: Wrap(spacing: 8, children: [
            IconButton(
                icon: const Icon(Icons.edit),
                onPressed: () => _editTask(id, name)),
            if (!isArchived)
              IconButton(
                icon: const Icon(Icons.archive),
                onPressed: () => _confirm(
                    'Arşivle',
                    '"$name" bugünden itibaren arşivlenecek.',
                    () => repo.archiveTask(id)),
              ),
            if (isArchived)
              IconButton(
                icon: const Icon(Icons.unarchive),
                onPressed: () => _confirm(
                    'Geri al',
                    '"$name" yeniden aktif edilsin mi?',
                    () => repo.restoreTask(id)),
              ),
            IconButton(
              icon: const Icon(Icons.delete_forever),
              onPressed: () => _confirm(
                  'Kalıcı sil',
                  '"$name" kalıcı silinecek (geçmiş tikler dahil).',
                  () => repo.deleteTaskPermanently(id)),
            ),
          ]),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Görevler'),
        bottom: TabBar(
            controller: _tab,
            tabs: const [Tab(text: 'Aktif'), Tab(text: 'Arşiv')]),
      ),
      body: TabBarView(
        controller: _tab,
        children: [
          active.isEmpty
              ? const Center(child: Text('Aktif görev yok.'))
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: active.length,
                  itemBuilder: (_, i) => row(active[i], false)),
          archived.isEmpty
              ? const Center(child: Text('Arşiv görev yok.'))
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: archived.length,
                  itemBuilder: (_, i) => row(archived[i], true)),
        ],
      ),
    );
  }
}

/// ------------------------------
/// Analytics
/// ------------------------------

enum AnalyticsMode { weekly, monthly }

class AnalyticsScreen extends StatefulWidget {
  final Repo repo;
  const AnalyticsScreen({super.key, required this.repo});

  @override
  State<AnalyticsScreen> createState() => _AnalyticsScreenState();
}

class _AnalyticsScreenState extends State<AnalyticsScreen> {
  Repo get repo => widget.repo;

  AnalyticsMode _mode = AnalyticsMode.weekly;
  DateTime _anchor = dateOnly(DateTime.now());

  DateTime _startOfWeek(DateTime d) {
    final dd = dateOnly(d);
    final diff = dd.weekday - DateTime.monday;
    return dd.subtract(Duration(days: diff));
  }

  DateTimeRange _rangeForAnchor() {
    final a = dateOnly(_anchor);
    if (_mode == AnalyticsMode.weekly) {
      final s = _startOfWeek(a);
      return DateTimeRange(start: s, end: s.add(const Duration(days: 6)));
    } else {
      final s = DateTime(a.year, a.month, 1);
      final e = DateTime(a.year, a.month + 1, 0);
      return DateTimeRange(start: s, end: e);
    }
  }

  List<DateTime> _daysInRange(DateTimeRange r) {
    final days = <DateTime>[];
    DateTime cur = dateOnly(r.start);
    final end = dateOnly(r.end);
    while (!cur.isAfter(end)) {
      days.add(cur);
      cur = cur.add(const Duration(days: 1));
    }
    return days;
  }

  void _prev() => setState(() => _anchor = _mode == AnalyticsMode.weekly
      ? _anchor.subtract(const Duration(days: 7))
      : DateTime(_anchor.year, _anchor.month - 1, 1));
  void _next() => setState(() => _anchor = _mode == AnalyticsMode.weekly
      ? _anchor.add(const Duration(days: 7))
      : DateTime(_anchor.year, _anchor.month + 1, 1));
  void _today() => setState(() => _anchor = dateOnly(DateTime.now()));

  String _title(DateTimeRange r) => _mode == AnalyticsMode.weekly
      ? 'Hafta: ${humanDate(r.start)} - ${humanDate(r.end)}'
      : 'Ay: ${r.start.month.toString().padLeft(2, '0')}.${r.start.year}';

  Color _tierColor(double ratio, ColorScheme cs) {
    if (ratio >= 0.80) return cs.primary;
    if (ratio >= 0.60) return cs.tertiary;
    if (ratio >= 0.40) return cs.secondary;
    if (ratio >= 0.20) return Colors.orange.shade700;
    return Colors.red.shade700;
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final range = _rangeForAnchor();
    final days = _daysInRange(range);

    final ratios = days.map((d) => repo.ratioForDate(d)).toList();
    final avg =
        ratios.isEmpty ? 0.0 : ratios.reduce((a, b) => a + b) / ratios.length;

    int totalTasks = 0, doneTasks = 0, daysAbove = 0, daysBelow = 0;
    final target = repo.targetRatio();

    for (final d in days) {
      final tot = repo.totalCountForDate(d);
      final dn = repo.completedCountForDate(d);
      totalTasks += tot;
      doneTasks += dn;
      if (tot > 0) {
        if (dn / tot >= target) {
          daysAbove++;
        } else {
          daysBelow++;
        }
      }
    }
    final remaining = max(0, totalTasks - doneTasks);

    // Task stats
    final tasks = repo.getAllTasks();
    final activeInRange =
        tasks.where((t) => days.any((d) => taskIsValidOn(t, d))).toList();

    final stats = <_TaskStat>[];
    for (final t in activeInRange) {
      final id = t['id'] as String;
      final name = t['name'] as String;
      int validDays = 0, doneDays = 0;
      for (final d in days) {
        if (!taskIsValidOn(t, d)) continue;
        validDays++;
        if (repo.isTaskDone(d, id)) doneDays++;
      }
      if (validDays > 0)
        stats.add(
            _TaskStat(name: name, validDays: validDays, doneDays: doneDays));
    }
    stats.sort((a, b) => a.rate.compareTo(b.rate));
    final weakest3 = stats.take(3).toList();

    // Weekday averages
    final sum = List<double>.filled(7, 0);
    final cnt = List<int>.filled(7, 0);
    for (final d in days) {
      final tot = repo.totalCountForDate(d);
      if (tot == 0) continue;
      final idx = d.weekday - 1;
      sum[idx] += repo.ratioForDate(d);
      cnt[idx] += 1;
    }
    final weekdayAvg =
        List<double>.generate(7, (i) => cnt[i] == 0 ? 0 : sum[i] / cnt[i]);

    // 90-day heatmap
    final heatEnd = dateOnly(DateTime.now());
    final heatStart = heatEnd.subtract(const Duration(days: 89));
    final heatDates = <DateTime>[];
    DateTime cur = heatStart;
    while (!cur.isAfter(heatEnd)) {
      heatDates.add(cur);
      cur = cur.add(const Duration(days: 1));
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Analitik')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SegmentedButton<AnalyticsMode>(
            segments: const [
              ButtonSegment(
                  value: AnalyticsMode.weekly,
                  label: Text('Haftalık'),
                  icon: Icon(Icons.view_week)),
              ButtonSegment(
                  value: AnalyticsMode.monthly,
                  label: Text('Aylık'),
                  icon: Icon(Icons.calendar_view_month)),
            ],
            selected: {_mode},
            onSelectionChanged: (s) => setState(() => _mode = s.first),
          ),
          const SizedBox(height: 12),
          Card(
            elevation: 0.6,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              child: Row(
                children: [
                  IconButton(
                      onPressed: _prev, icon: const Icon(Icons.chevron_left)),
                  Expanded(
                      child: Center(
                          child: Text(_title(range),
                              style: const TextStyle(
                                  fontWeight: FontWeight.w900)))),
                  IconButton(
                      onPressed: _next, icon: const Icon(Icons.chevron_right)),
                  const SizedBox(width: 6),
                  TextButton.icon(
                      onPressed: _today,
                      icon: const Icon(Icons.today),
                      label: const Text('Bugün')),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                  child: _KpiCard(
                      title: 'Ortalama', value: '${(avg * 100).round()}%')),
              const SizedBox(width: 12),
              Expanded(
                  child: _KpiCard(
                      title: 'Toplam',
                      value: '$totalTasks\nTamam: $doneTasks')),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                  child: _KpiCard(
                      title: 'Hedef', value: '${(target * 100).round()}%')),
              const SizedBox(width: 12),
              Expanded(
                  child: _KpiCard(
                      title: 'Üst/Alt', value: '$daysAbove / $daysBelow')),
            ],
          ),
          const SizedBox(height: 18),
          const Text('Günlük trend',
              style: TextStyle(fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          _LineChartPercent(days: days, ratios: ratios),
          const SizedBox(height: 18),
          const Text('Tamamlanan / Kalan',
              style: TextStyle(fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          _PieChart(done: doneTasks, remaining: remaining),
          const SizedBox(height: 18),
          const Text('Görev bazlı başarı',
              style: TextStyle(fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Card(
            elevation: 0.6,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: stats.isEmpty
                  ? const Text('Bu periyotta veri yok.')
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (weakest3.isNotEmpty) ...[
                          Row(children: const [
                            Icon(Icons.warning_amber, size: 18),
                            SizedBox(width: 6),
                            Text('En zayıf 3',
                                style: TextStyle(fontWeight: FontWeight.w900)),
                          ]),
                          const SizedBox(height: 10),
                          for (final s in weakest3)
                            _TaskStatRow(
                                name: s.name,
                                done: s.doneDays,
                                total: s.validDays,
                                color: _tierColor(s.rate, cs)),
                          const Divider(height: 24),
                        ],
                        const Text('Tümü',
                            style: TextStyle(fontWeight: FontWeight.w900)),
                        const SizedBox(height: 10),
                        for (final s in stats.reversed)
                          _TaskStatRow(
                              name: s.name,
                              done: s.doneDays,
                              total: s.validDays,
                              color: _tierColor(s.rate, cs)),
                      ],
                    ),
            ),
          ),
          const SizedBox(height: 18),
          const Text('Haftanın günü',
              style: TextStyle(fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Card(
            elevation: 0.6,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                children: List.generate(7, (i) {
                  const names = [
                    'Pzt',
                    'Sal',
                    'Çar',
                    'Per',
                    'Cum',
                    'Cmt',
                    'Paz'
                  ];
                  final v = weekdayAvg[i];
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: Row(
                      children: [
                        SizedBox(
                            width: 34,
                            child: Text(names[i],
                                style: const TextStyle(
                                    fontWeight: FontWeight.w800))),
                        Expanded(
                          child: LinearProgressIndicator(
                            value: v.clamp(0, 1),
                            minHeight: 10,
                            borderRadius: BorderRadius.circular(999),
                            backgroundColor:
                                cs.outlineVariant.withOpacity(0.35),
                            valueColor: AlwaysStoppedAnimation<Color>(
                                _tierColor(v, cs)),
                          ),
                        ),
                        const SizedBox(width: 10),
                        SizedBox(
                            width: 44, child: Text('${(v * 100).round()}%')),
                      ],
                    ),
                  );
                }),
              ),
            ),
          ),
          const SizedBox(height: 18),
          const Text('Son 90 gün',
              style: TextStyle(fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Card(
            elevation: 0.6,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: _Heatmap90Days(
                dates: heatDates,
                ratioOf: (d) => repo.ratioForDate(d),
                tierColor: (r) => _tierColor(r, cs),
                isPerfect: (d) => repo.isPerfectDay(d),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TaskStat {
  final String name;
  final int validDays;
  final int doneDays;
  _TaskStat(
      {required this.name, required this.validDays, required this.doneDays});
  double get rate => validDays == 0 ? 0 : doneDays / validDays;
}

class _TaskStatRow extends StatelessWidget {
  final String name;
  final int done;
  final int total;
  final Color color;

  const _TaskStatRow(
      {required this.name,
      required this.done,
      required this.total,
      required this.color});

  @override
  Widget build(BuildContext context) {
    final v = total == 0 ? 0.0 : done / total;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Expanded(
              child: Text(name,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w800))),
          const SizedBox(width: 10),
          SizedBox(
              width: 60,
              child: Text('$done/$total', textAlign: TextAlign.right)),
          const SizedBox(width: 10),
          SizedBox(
            width: 92,
            child: LinearProgressIndicator(
              value: v.clamp(0, 1),
              minHeight: 8,
              borderRadius: BorderRadius.circular(999),
              backgroundColor: Theme.of(context)
                  .colorScheme
                  .outlineVariant
                  .withOpacity(0.35),
              valueColor: AlwaysStoppedAnimation<Color>(color),
            ),
          ),
        ],
      ),
    );
  }
}

class _Heatmap90Days extends StatelessWidget {
  final List<DateTime> dates;
  final double Function(DateTime d) ratioOf;
  final Color Function(double ratio) tierColor;
  final bool Function(DateTime d) isPerfect;

  const _Heatmap90Days(
      {required this.dates,
      required this.ratioOf,
      required this.tierColor,
      required this.isPerfect});

  DateTime _startOfWeek(DateTime d) {
    final dd = dateOnly(d);
    final diff = dd.weekday - DateTime.monday;
    return dd.subtract(Duration(days: diff));
  }

  @override
  Widget build(BuildContext context) {
    if (dates.isEmpty) return const Text('Veri yok');

    final start = _startOfWeek(dates.first);
    final end = dates.last;
    final weeks = <List<DateTime>>[];

    DateTime cursor = start;
    while (!cursor.isAfter(end)) {
      weeks.add(List.generate(7, (i) => cursor.add(Duration(days: i))));
      cursor = cursor.add(const Duration(days: 7));
    }

    final set = {for (final d in dates) dateKey(d)};

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: weeks.map((w) {
          return Padding(
            padding: const EdgeInsets.only(right: 6),
            child: Column(
              children: w.map((d) {
                final inside = set.contains(dateKey(d));
                final r = inside ? ratioOf(d) : 0.0;
                final c = inside
                    ? tierColor(r)
                    : Theme.of(context)
                        .colorScheme
                        .outlineVariant
                        .withOpacity(0.25);
                return Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Stack(
                    children: [
                      Container(
                          width: 14,
                          height: 14,
                          decoration: BoxDecoration(
                              color: c,
                              borderRadius: BorderRadius.circular(4))),
                      if (inside && isPerfect(d))
                        const Positioned(
                            right: -2,
                            bottom: -4,
                            child: Icon(Icons.local_fire_department,
                                size: 12, color: Colors.deepOrange)),
                    ],
                  ),
                );
              }).toList(),
            ),
          );
        }).toList(),
      ),
    );
  }
}

/// ------------------------------
/// Charts / KPI
/// ------------------------------

class _KpiCard extends StatelessWidget {
  final String title;
  final String value;
  const _KpiCard({required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0.6,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title,
              style: Theme.of(context)
                  .textTheme
                  .labelLarge
                  ?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          Text(value,
              style: Theme.of(context)
                  .textTheme
                  .titleMedium
                  ?.copyWith(fontWeight: FontWeight.w900)),
        ]),
      ),
    );
  }
}

class _LineChartPercent extends StatelessWidget {
  final List<DateTime> days;
  final List<double> ratios;
  const _LineChartPercent({required this.days, required this.ratios});

  @override
  Widget build(BuildContext context) {
    if (days.isEmpty)
      return const SizedBox(
          height: 220, child: Center(child: Text('Veri yok')));

    final spots = <FlSpot>[];
    for (int i = 0; i < ratios.length; i++) {
      spots.add(FlSpot(i.toDouble(), ratios[i] * 100));
    }

    return SizedBox(
      height: 240,
      child: LineChart(
        LineChartData(
          minY: 0,
          maxY: 100,
          gridData: const FlGridData(show: true),
          titlesData: FlTitlesData(
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                  showTitles: true,
                  reservedSize: 38,
                  interval: 20,
                  getTitlesWidget: (v, _) => Text('${v.toInt()}')),
            ),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                interval: max(1, (days.length / 6).floor()).toDouble(),
                getTitlesWidget: (v, _) {
                  final i = v.toInt();
                  if (i < 0 || i >= days.length) return const SizedBox.shrink();
                  return Text('${days[i].day}');
                },
              ),
            ),
            rightTitles:
                const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            topTitles:
                const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          ),
          lineBarsData: [
            LineChartBarData(
              spots: spots,
              isCurved: true,
              dotData: const FlDotData(show: true),
              barWidth: 3,
            )
          ],
          borderData: FlBorderData(show: true),
        ),
      ),
    );
  }
}

class _PieChart extends StatelessWidget {
  final int done;
  final int remaining;
  const _PieChart({required this.done, required this.remaining});

  @override
  Widget build(BuildContext context) {
    final total = max(1, done + remaining);
    final donePct = (done / total) * 100;

    return SizedBox(
      height: 220,
      child: Row(
        children: [
          Expanded(
            child: PieChart(
              PieChartData(
                centerSpaceRadius: 45,
                sectionsSpace: 2,
                sections: [
                  PieChartSectionData(
                      value: done.toDouble(), title: '', radius: 60),
                  PieChartSectionData(
                      value: remaining.toDouble(), title: '', radius: 60),
                ],
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Card(
              elevation: 0.6,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Tamamlanan: $done',
                          style: const TextStyle(fontWeight: FontWeight.w900)),
                      const SizedBox(height: 6),
                      Text('Kalan: $remaining',
                          style: const TextStyle(fontWeight: FontWeight.w900)),
                      const SizedBox(height: 12),
                      Text('Tamamlama: ${donePct.toStringAsFixed(0)}%'),
                    ]),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
